﻿using Microsoft.Extensions.Logging;
using Moq;
using VMO2.Controllers;
using VMO2.Interfaces;
using AutoFixture;
using VMO2.Models;
namespace VMO2.Tests.Controllers;

public class HomeControllerTests
{
    private Mock<ILogger<HomeController>> _loggerMock;
    protected Mock<ISalesService> _salesServiceMock { get; set; }
    private Fixture _fixture;
    protected HomeController _homeController { get; set; }

    public HomeControllerTests()
    {
        _loggerMock = new Mock<ILogger<HomeController>>();
        _salesServiceMock = new Mock<ISalesService>();
        _fixture = new Fixture();
        _homeController = new HomeController(_loggerMock.Object, _salesServiceMock.Object);
    }
    [Fact]
    public void IndexCall_ReturnsView()
    {
        _salesServiceMock.Setup(a => a.GetSalesList()).Returns(_fixture.Create<List<SalesModel>>());
        var result = _homeController.Index(1);
        Assert.True(((Microsoft.AspNetCore.Mvc.ViewResult)result).ViewData.Count > 0);
    }
}

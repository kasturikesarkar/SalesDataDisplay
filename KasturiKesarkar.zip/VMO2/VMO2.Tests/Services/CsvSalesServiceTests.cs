﻿using AutoFixture;
using Microsoft.Extensions.Logging;
using Moq;
using VMO2.Services;

namespace VMO2.Tests.Services;

public class CsvSalesServiceTests
{
    private Mock<ILogger<CsvSalesService>> _loggerMock;
    private Fixture _fixture;
    protected CsvSalesService _csvSalesService { get; set; }
    public CsvSalesServiceTests()
    {
        _loggerMock = new Mock<ILogger<CsvSalesService>>();
        _fixture = new Fixture();
        _csvSalesService = new CsvSalesService(_loggerMock.Object);
    }
    [Fact]
    public void GetSalesList_ReturnsList()
    {
        var result = _csvSalesService.GetSalesList();
        Assert.True(result.Count == 2);
    }
}

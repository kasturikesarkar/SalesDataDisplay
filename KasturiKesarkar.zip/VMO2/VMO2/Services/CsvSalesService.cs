﻿using CsvHelper.Configuration;
using CsvHelper;
using System.Globalization;
using VMO2.Interfaces;
using VMO2.Models;

namespace VMO2.Services;

public class CsvSalesService : ISalesService
{
    private readonly ILogger<CsvSalesService> _logger;
    private const string _filename = "Data.csv";
    public CsvSalesService(ILogger<CsvSalesService> logger)
    {
        _logger = logger;
    }
    public List<SalesModel> GetSalesList()
    {
        _logger.LogInformation("Get Sales List");
        var data = new SalesListModel();

        try
        {
            var config = new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HasHeaderRecord = false,
            };
            using (var reader = new StreamReader(_filename))
            using (var csv = new CsvReader(reader, config))
            {
                var records = csv.GetRecords<SalesModel>();
                data.Sales = records.ToList();
            }
            data.Sales.RemoveAt(0);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error in Get Sales List");
        }
        return data.Sales!;
    }
}

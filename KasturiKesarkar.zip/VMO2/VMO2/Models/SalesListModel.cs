﻿namespace VMO2.Models;

public class SalesListModel
{
    public List<SalesModel>? Sales { get; set; }

}

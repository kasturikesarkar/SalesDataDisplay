﻿using VMO2.Models;

namespace VMO2.Interfaces;

public interface ISalesService
{
    List<SalesModel> GetSalesList();
}

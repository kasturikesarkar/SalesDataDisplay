using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using VMO2.Interfaces;
using VMO2.Models;
using X.PagedList.Extensions;



namespace VMO2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ISalesService _salesService;
        private const int _pageSize = 50;

        public HomeController(ILogger<HomeController> logger, ISalesService salesService)
        {
            _logger = logger;
            _salesService = salesService;
        }

        public IActionResult Index(int? Page)
        {
            _logger.LogInformation("Display Sales Data");
            try
            {
                ViewData["Sales"] = _salesService.GetSalesList().ToPagedList(Page ?? 1, _pageSize);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error displaying Sales Data");
            }
            return View();

        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
